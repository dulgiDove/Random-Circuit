using Unity.Netcode;
using UnityEngine;

public class GoalLine : MonoBehaviour
{
    private GameFlowManager gameFlowManager;
    private bool localPlayerFinished;

    private void Awake()
    {
        gameFlowManager = FindAnyObjectByType<GameFlowManager>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (localPlayerFinished)
        {
            return;
        }

        NetworkObject playerNetworkObject =
            other.GetComponentInParent<NetworkObject>();

        if (playerNetworkObject == null || !playerNetworkObject.IsOwner)
        {
            return;
        }

        localPlayerFinished = true;

        if (gameFlowManager != null)
        {
            gameFlowManager.ReportFinish();
        }
    }
}