using Unity.Cinemachine;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NetworkPlayerSetup : NetworkBehaviour
{
    [Header("Local Player Components")]
    [SerializeField]
    private PlayerMovement playerMovement;

    [SerializeField]
    private PlayerInteraction playerInteraction;

    [SerializeField]
    private PlayerRespawn playerRespawn;

    [SerializeField]
    private CharacterController characterController;

    [SerializeField]
    private PlayerAnimation playerAnimation;

    [Header("Camera")]
    [SerializeField]
    private Transform cameraTarget;

    public override void OnNetworkSpawn()
    {
        bool isLocalPlayer = IsOwner;

        playerMovement.enabled = isLocalPlayer;
        playerInteraction.enabled = isLocalPlayer;
        playerRespawn.enabled = isLocalPlayer;
        characterController.enabled = isLocalPlayer;
        playerAnimation.enabled = isLocalPlayer;

        if (!IsOwner)
        {
            return;
        }

        // GameFlowManager가 GO를 줄 때까지 이동 금지
        playerMovement.SetControlsLocked(true);

        // Retry 등으로 Scene이 다시 로드될 때 새 Scene 참조를 다시 연결
        SceneManager.sceneLoaded += OnSceneLoaded;

        BindSceneReferences();
    }

    public override void OnNetworkDespawn()
    {
        if (IsOwner)
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
        }
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        BindSceneReferences();
    }

    private void BindSceneReferences()
    {
        // 새 Scene의 Main Camera를 PlayerMovement에 연결
        if (Camera.main != null)
        {
            playerMovement.SetCameraTransform(Camera.main.transform);
        }

        // 활성 / 비활성 Cinemachine Camera 모두 Local Player를 추적
        CinemachineCamera[] cameras =
            FindObjectsByType<CinemachineCamera>(
                FindObjectsInactive.Include,
                FindObjectsSortMode.None
            );

        foreach (CinemachineCamera cam in cameras)
        {
            cam.Target.TrackingTarget = cameraTarget;
        }
    }
}