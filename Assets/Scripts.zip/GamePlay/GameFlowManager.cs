using Unity.Netcode;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameFlowManager : NetworkBehaviour
{
    [Header("Start UI")]
    [SerializeField]
    private GameObject startOverlay;
    [SerializeField]
    private TMP_Text countdownText;

    [Header("Countdown")]
    [SerializeField]
    private float numberDuration = 1f;
    [SerializeField]
    private float goDuration = 0.5f;

    [Header("Clear UI")]
    [SerializeField]
    private GameObject clearOverlay;
    [SerializeField]
    private TMP_Text clearTimeText;
    [SerializeField]
    private GameObject resultGroup;
    [SerializeField]
    private GameObject mainMenuButton;
    [SerializeField]
    private TMP_Text finalRankText;
    [SerializeField]
    private float resultDelay = 0.8f;

    [Header("Network")]
    [SerializeField]
    private int minimumPlayersToStart = 2;

    private readonly NetworkVariable<double> raceStartTime =
        new NetworkVariable<double>(-1d);

    private readonly HashSet<ulong> finishedClients = new HashSet<ulong>();
    private int finishCount;

    private bool waitingForRetry;

    private readonly HashSet<ulong> retryReadyClients =
        new HashSet<ulong>();

    private bool gameStarted;
    public bool GameStarted => gameStarted;

    private float elapsedTime;
    public float ElapsedTime => elapsedTime;

    private bool gameFinished;

    private PlayerMovement playerMovement;

    private void Start()
    {
        clearOverlay.SetActive(false);
        startOverlay.SetActive(true);
        countdownText.text = "Waiting...";
    }

    private void Update()
    {
        if (waitingForRetry)
        {
            return;
        }

        if (!IsSpawned || raceStartTime.Value < 0d)
        {
            return;
        }

        double currentTime = NetworkManager.ServerTime.Time;
        double remainingTime = raceStartTime.Value - currentTime;

        // Countdown
        if (!gameStarted)
        {
            if (remainingTime > 0d)
            {
                int number = Mathf.Clamp(
                    Mathf.CeilToInt((float)(remainingTime / numberDuration)),
                    1,
                    3
                );

                countdownText.text = number.ToString();
                return;
            }

            countdownText.text = "GO!";

            gameStarted = true;
            gameFinished = false;
            elapsedTime = 0f;

            if (playerMovement != null)
            {
                playerMovement.SetControlsLocked(false);
            }
        }

        // 모든 Client가 같은 NetworkTime 기준으로 기록
        if (!gameFinished)
        {
            elapsedTime =
                Mathf.Max(0f, (float)(currentTime - raceStartTime.Value));
        }

        if (currentTime >= raceStartTime.Value + goDuration &&
            startOverlay.activeSelf)
        {
            startOverlay.SetActive(false);
        }
    }

    public override void OnNetworkSpawn()
    {
        Debug.Log($"[GameFlow] Spawned - Server:{IsServer}, Client:{IsClient}");

        StartCoroutine(BindLocalPlayer());

        if (IsServer)
        {
            StartCoroutine(ScheduleRaceStart());
        }
    }

    private IEnumerator BindLocalPlayer()
    {
        yield return new WaitUntil(() =>
            NetworkManager.Singleton.LocalClient.PlayerObject != null
        );

        playerMovement =
            NetworkManager.Singleton.LocalClient.PlayerObject
                .GetComponent<PlayerMovement>();

        playerMovement.SetControlsLocked(true);
    }

    private IEnumerator ScheduleRaceStart()
    {
        Debug.Log("[GameFlow] Waiting for players...");

        while (NetworkManager.Singleton.ConnectedClients.Count < minimumPlayersToStart)
        {
            Debug.Log(
                $"[GameFlow] Players: {NetworkManager.Singleton.ConnectedClients.Count}/{minimumPlayersToStart}"
            );

            yield return new WaitForSeconds(1f);
        }

        Debug.Log("[GameFlow] Enough players. Starting countdown.");

        yield return new WaitForSeconds(0.5f);

        raceStartTime.Value =
            NetworkManager.ServerTime.Time +
            numberDuration * 3f;

        Debug.Log($"[GameFlow] Race start time: {raceStartTime.Value}");
    }

    private IEnumerator FinishGameRoutine()
    {
        clearOverlay.SetActive(true);
        resultGroup.SetActive(false);
        mainMenuButton.SetActive(false);
        yield return new WaitForSeconds(resultDelay);

        clearTimeText.text = GetFormattedTime();
        resultGroup.SetActive(true);
        mainMenuButton.SetActive(true);
    }

    public void FinishGame()
    {
        if (!gameStarted || gameFinished)
        {
            return;
        }

        gameFinished = true;
        GameRecords.RecordClear(elapsedTime);
        playerMovement.SetControlsLocked(true);
        StartCoroutine(FinishGameRoutine());
    }

    public string GetFormattedTime()
    {
        int minutes = Mathf.FloorToInt(elapsedTime / 60f);
        int seconds = Mathf.FloorToInt(elapsedTime % 60f);
        int milliseconds = Mathf.FloorToInt((elapsedTime * 100f) % 100f);

        return string.Format("{0:00}:{1:00}.{2:00}", minutes, seconds, milliseconds);
    }

    public void RetryGame()
    {
        if (waitingForRetry)
        {
            return;
        }

        waitingForRetry = true;

        // 나만 Waiting 화면으로 전환
        clearOverlay.SetActive(false);
        startOverlay.SetActive(true);
        countdownText.text = "Waiting...";

        if (playerMovement != null)
        {
            playerMovement.SetControlsLocked(true);
        }

        RetryReadyServerRpc();
    }

    [ServerRpc(RequireOwnership = false)]
    private void RetryReadyServerRpc(ServerRpcParams rpcParams = default)
    {
        ulong clientId = rpcParams.Receive.SenderClientId;

        if (!retryReadyClients.Add(clientId))
        {
            return;
        }

        Debug.Log(
            $"Retry Ready: {retryReadyClients.Count}/" +
            $"{NetworkManager.Singleton.ConnectedClients.Count}"
        );

        if (retryReadyClients.Count >=
            NetworkManager.Singleton.ConnectedClients.Count)
        {
            ReloadGameplay();
        }
    }

    private void ReloadGameplay()
    {
        string sceneName = SceneManager.GetActiveScene().name;

        NetworkManager.SceneManager.LoadScene(
            sceneName,
            LoadSceneMode.Single
        );
    }

    public void ReturnToMainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }

    public void ReportFinish()
    {
        ReportFinishServerRpc();
    }

    [ServerRpc(RequireOwnership = false)]
    private void ReportFinishServerRpc(ServerRpcParams rpcParams = default)
    {
        ulong clientId = rpcParams.Receive.SenderClientId;

        if (finishedClients.Contains(clientId))
        {
            return;
        }

        finishedClients.Add(clientId);
        finishCount++;

        Debug.Log($"{finishCount}등 - Client {clientId}");

        ClientRpcParams clientRpcParams = new ClientRpcParams
        {
            Send = new ClientRpcSendParams
            {
                TargetClientIds = new ulong[] { clientId }
            }
        };

        SetFinalRankClientRpc(finishCount, clientRpcParams);

        if (finishCount >= NetworkManager.Singleton.ConnectedClients.Count)
        {
            EndRaceClientRpc();
        }
    }

    [ClientRpc]
    private void SetFinalRankClientRpc(
        int rank,
        ClientRpcParams clientRpcParams = default)
    {
        if (finalRankText != null)
        {
            finalRankText.text = $"Rank {rank}";
        }
    }

    [ClientRpc]
    private void EndRaceClientRpc()
    {
        if (gameFinished)
        {
            return;
        }

        gameFinished = true;

        if (playerMovement != null)
        {
            playerMovement.SetControlsLocked(true);
        }

        StartCoroutine(FinishGameRoutine());
    }
}