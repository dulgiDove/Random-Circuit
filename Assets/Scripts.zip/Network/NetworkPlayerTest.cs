using Unity.Netcode;
using UnityEngine;

public class NetworkPlayerTest : NetworkBehaviour
{
    public override void OnNetworkSpawn()
    {
        if (!IsServer)
            return;

        transform.position = new Vector3(
            OwnerClientId * 2f,
            0f,
            0f
        );
    }
}