using System;
using TMPro;
using Unity.Services.Authentication;
using Unity.Services.Core;
using Unity.Services.Multiplayer;
using Unity.Netcode;
using UnityEngine.SceneManagement;
using UnityEngine;

public class MultiplayerSessionManager : MonoBehaviour
{
    [Header("Play Panel")]
    [SerializeField]
    private GameObject playPanel;

    [Header("Views")]
    [SerializeField]
    private GameObject modeSelect;

    [SerializeField]
    private GameObject multiSelect;

    [SerializeField]
    private GameObject joinView;

    [SerializeField]
    private GameObject roomView;


    [Header("Join")]
    [SerializeField]
    private TMP_InputField joinCodeInput;


    [Header("Room")]
    [SerializeField]
    private TMP_Text roomCodeText;

    [SerializeField]
    private TMP_Text playerCountText;

    [SerializeField]
    private GameObject hostPlayButton;

    [SerializeField]
    private GameObject waitingText;


    private ISession currentSession;
    private bool servicesInitialized;

    private bool isStartingGame;


    private async void Start()
    {
        playPanel.SetActive(false);

        try
        {
            await InitializeServicesAsync();
        }
        catch (Exception exception)
        {
            Debug.LogException(exception);
        }
    }


    // =========================
    // UGS
    // =========================

    private async System.Threading.Tasks.Task InitializeServicesAsync()
    {
        if (servicesInitialized)
        {
            return;
        }

        await UnityServices.InitializeAsync();

        if (!AuthenticationService.Instance.IsSignedIn)
        {
            await AuthenticationService.Instance.SignInAnonymouslyAsync();
        }

        servicesInitialized = true;

        Debug.Log(
            $"UGS Login Success: {AuthenticationService.Instance.PlayerId}"
        );
    }


    // =========================
    // View
    // =========================

    public void ShowModeSelect()
    {
        modeSelect.SetActive(true);
        multiSelect.SetActive(false);
        joinView.SetActive(false);
        roomView.SetActive(false);
    }

    public void ShowMultiSelect()
    {
        modeSelect.SetActive(false);
        multiSelect.SetActive(true);
        joinView.SetActive(false);
        roomView.SetActive(false);
    }

    public void ShowJoinView()
    {
        modeSelect.SetActive(false);
        multiSelect.SetActive(false);
        joinView.SetActive(true);
        roomView.SetActive(false);

        joinCodeInput.text = "";
    }

    private void ShowRoomView()
    {
        modeSelect.SetActive(false);
        multiSelect.SetActive(false);
        joinView.SetActive(false);
        roomView.SetActive(true);

        RefreshRoomUI();
    }


    // =========================
    // Create
    // =========================

    public async void CreateRoom()
    {
        if (!servicesInitialized)
        {
            return;
        }

        try
        {
            SessionOptions options = new SessionOptions
            {
                MaxPlayers = 4
            };

            // Relay는 아직 시작하지 않는다.
            currentSession =
                await MultiplayerService.Instance
                    .CreateSessionAsync(options);

            SubscribeSessionEvents();

            Debug.Log(
                $"Room Created - Code: {currentSession.Code}"
            );

            ShowRoomView();
        }
        catch (Exception exception)
        {
            Debug.LogException(exception);
        }
    }


    // =========================
    // Join
    // =========================

    public async void JoinRoom()
    {
        if (!servicesInitialized)
        {
            return;
        }

        string joinCode =
            joinCodeInput.text
                .Trim()
                .ToUpperInvariant();

        if (string.IsNullOrEmpty(joinCode))
        {
            return;
        }

        try
        {
            currentSession =
                await MultiplayerService.Instance
                    .JoinSessionByCodeAsync(joinCode);

            SubscribeSessionEvents();

            Debug.Log(
                $"Joined Room - Code: {currentSession.Code}"
            );

            ShowRoomView();
        }
        catch (Exception exception)
        {
            Debug.LogException(exception);
        }
    }


    // =========================
    // Room
    // =========================

    private void SubscribeSessionEvents()
    {
        if (currentSession == null)
        {
            return;
        }

        currentSession.PlayerJoined += OnPlayerJoined;
        currentSession.PlayerHasLeft += OnPlayerHasLeft;
        currentSession.RemovedFromSession += OnRemovedFromSession;
    }

    private void UnsubscribeSessionEvents()
    {
        if (currentSession == null)
        {
            return;
        }

        currentSession.PlayerJoined -= OnPlayerJoined;
        currentSession.PlayerHasLeft -= OnPlayerHasLeft;
        currentSession.RemovedFromSession -= OnRemovedFromSession;
    }

    private void OnPlayerJoined(string playerId)
    {
        Debug.Log($"Player Joined: {playerId}");
        RefreshRoomUI();
    }

    private void OnPlayerHasLeft(string playerId)
    {
        Debug.Log($"Player Left: {playerId}");
        RefreshRoomUI();
    }

    private void OnRemovedFromSession()
    {
        Debug.Log("Removed from session");

        currentSession = null;
        ShowMultiSelect();
    }

    private void RefreshRoomUI()
    {
        if (currentSession == null)
        {
            return;
        }

        roomCodeText.text =
            $"Code : {currentSession.Code}";

        playerCountText.text =
            $"Players : {currentSession.PlayerCount} / {currentSession.MaxPlayers}";

        bool isHost = currentSession.IsHost;

        hostPlayButton.SetActive(isHost);
        waitingText.SetActive(!isHost);
    }


    // =========================
    // Leave
    // =========================

    public async void LeaveRoom()
    {
        if (currentSession == null)
        {
            ShowMultiSelect();
            return;
        }

        try
        {
            UnsubscribeSessionEvents();

            await currentSession.LeaveAsync();

            currentSession = null;

            ShowMultiSelect();
        }
        catch (Exception exception)
        {
            Debug.LogException(exception);
        }
    }

    public void OpenPlayPanel()
    {
        playPanel.SetActive(true);
        ShowModeSelect();
    }

    public void ClosePlayPanel()
    {
        playPanel.SetActive(false);
    }

    public async void StartMultiplayerGame()
    {
        if (currentSession == null ||
            !currentSession.IsHost ||
            isStartingGame)
        {
            return;
        }

        try
        {
            isStartingGame = true;
            hostPlayButton.SetActive(false);

            IHostSession hostSession = currentSession.AsHost();

            RelayNetworkOptions networkOptions =
                new RelayNetworkOptions(RelayProtocol.Default);

            await hostSession.Network.StartRelayNetworkAsync(
                networkOptions
            );

            Debug.Log("Relay network started.");

            NetworkManager.Singleton.SceneManager.LoadScene(
                "Gameplay",
                LoadSceneMode.Single
            );
        }
        catch (Exception exception)
        {
            Debug.LogException(exception);

            isStartingGame = false;

            if (currentSession != null &&
                currentSession.IsHost)
            {
                hostPlayButton.SetActive(true);
            }
        }
    }
}